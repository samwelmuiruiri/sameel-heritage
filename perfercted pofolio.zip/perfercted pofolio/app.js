// Tab switching
var tablinks = document.getElementsByClassName("tab-links");
var tabcontents = document.getElementsByClassName("tab-contents");

function opentab(tabname, event) {
    for (let tablink of tablinks) {
        tablink.classList.remove("active-link");
    }
    for (let tabcontent of tabcontents) {
        tabcontent.classList.remove("active-tabs");
    }
    document.getElementById(tabname).classList.add("active-tabs");
    event.currentTarget.classList.add("active-link");
}

// Mobile menu toggle
const navToggle = document.createElement("div");
navToggle.innerHTML = "☰";
navToggle.style.fontSize = "30px";
navToggle.style.cursor = "pointer";
document.querySelector("nav").prepend(navToggle);

navToggle.addEventListener("click", () => {
    document.querySelector("nav ul").classList.toggle("show");
});

// Smooth scrolling for anchor links
document.querySelectorAll("a[href^='#']").forEach(anchor => {
    anchor.addEventListener("click")
});